function myTest(document) {
    document.getElementById("lName").value = "";
    alert('Welcome to custom js');

}

function myTest1() {
   
    alert('button clicked');

}

$(function() {
    alert('Hello, custom js');
});