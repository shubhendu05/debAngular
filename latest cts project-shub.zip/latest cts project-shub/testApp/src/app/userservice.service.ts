import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './employee';
 
@Injectable()
export class UserService {
 
  private usersUrl: string;
  private addusersUrl: string;
  private sortId: string;
  private sortfName: string;
  private sortlName: string;
  private deleteid: string;
  
 
  constructor(private http: HttpClient) {
    this.usersUrl = 'http://localhost:8080/users';
    this.addusersUrl = 'http://localhost:8080/addusers';
    this.sortId = 'http://localhost:8080/sortId';
    this.sortfName = 'http://localhost:8080/sortfName';
    this.sortlName = 'http://localhost:8080/sortlName';
    this.deleteid='';
  }
 
  public findAll(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.usersUrl);
  }

  public sortbyId(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.sortId);
  }
  public sortbyfName(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.sortfName);
  }
  public sortbylName(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.sortlName);
  }
 
  public save(user: Employee) {
    return this.http.post<Employee>(this.addusersUrl, user);
  }

  public delete(eid: any) {
    return this.http.get<Employee>('http://localhost:8080/delete/'+eid);
  }
}