import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { UserService } from '../userservice.service';
declare const myTest1: any;


@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  users: Employee[];
  user:Employee;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.findAll().subscribe(data => {
      this.users = data;
    });
  }

  sortId() {
    myTest1();
    this.userService.sortbyId().subscribe(data => {
      this.users = data;
    });
  }

  sortfName() {
    
    this.userService.sortbyfName().subscribe(data => {
      this.users = data;
    });
  }

  sortlName() {
    
    this.userService.sortbylName().subscribe(data => {
      this.users = data;
    });
  }

  delete(user.eId)

}