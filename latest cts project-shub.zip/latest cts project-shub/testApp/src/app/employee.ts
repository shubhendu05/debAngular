export class Employee {
    eId:number;
    fName:string;
    lName:string;


}
