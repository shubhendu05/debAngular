import { Component, OnInit, Inject } from '@angular/core';
import { Employee } from '../employee';
import { UserService } from '../userservice.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DOCUMENT } from '@angular/common';
declare const myTest: any;

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent {
  user: Employee;
  constructor(@Inject(DOCUMENT) document,private route: ActivatedRoute, 
    private router: Router, 
      private userService: UserService) {

        this.user = new Employee();
       }

    onSubmit() {
        this.userService.save(this.user).subscribe(result => this.gotoUserList());
    }
     
      gotoUserList() {
        this.router.navigate(['/users']);
      }

      onClick() {
        myTest(document);
      }
}
