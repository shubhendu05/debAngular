# encoding: UTF-8

rpm_file = 'epel-release-6-8.noarch.rpm'

remote_file "/tmp/#{rpm_file}" do
  source "http://sdlcbrm.hiw.com/artifactory/yum-local/epel/#{rpm_file}"

  action :create
end

rpm_package 'epel' do
  source "/tmp/#{rpm_file}"

  action :install
end

file "/tmp/#{rpm_file}" do
  action :delete
end

package 'docker-io' do
  action :install
end

directory '/opt/esi-registry/certs' do
  owner 'root'
  group 'root'
  mode '0755'
  recursive true

  action :create
end

directory '/var/lib/esi-registry' do
  owner 'root'
  group 'root'
  mode '0755'
  recursive true

  action :create
end

cookbook_file '/opt/esi-registry/certs/registry.crt' do
  source 'registry.crt'
  owner 'root'
  group 'root'
  mode '0400'

  action :create
end

cookbook_file '/opt/esi-registry/certs/registry.key' do
  source 'registry.key'
  owner 'root'
  group 'root'
  mode '0400'

  action :create
end

docker_image 'registry' do
  tag '2'

  action :pull
end

docker_container 'esi-registry' do
  repo 'registry'
  tag '2'
  volumes [
              '/var/lib/esi-registry:/var/lib/registry',
              '/opt/esi-registry/certs:/certs'
          ]
  env [
          'REGISTRY_STORAGE_DELETE_ENABLED=true',
          'REGISTRY_HTTP_ADDR=0.0.0.0:80',
          'REGISTRY_HTTP_TLS_CERTIFICATE=/certs/registry.crt',
          'REGISTRY_HTTP_TLS_KEY=/certs/registry.key'
      ]
  port '80:80'
  restart_policy 'always'

  action :run
end

cron 'ESI Registry clean up' do
  minute '0'
  hour '0'
  weekday '0'

  user 'root'
  command 'docker exec esi-registry bin/registry garbage-collect /etc/docker/registry/config.yml'

  action :create
end
