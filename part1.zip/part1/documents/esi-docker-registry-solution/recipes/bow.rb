docker_image 'evedel/bow' do
  action :pull
end

docker_container 'esi-registry-bow' do
  repo 'evedel/bow'

  volumes '/var/lib/esi-registry-bow:/var/lib/bow'
  port '8080:19808'
  restart_policy 'always'

  action :run
end
