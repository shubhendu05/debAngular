# ESI Docker Registry

Cookbook to install Docker Registry on DC4 VMs.

## Platforms:

CentOS

## Dependencies:

 - docker

## Attributes

## Recipes

 - esi-docker-registry-solution::default

 Installs Docker Registry.

 - esi-docker-registry-solution::bow
 
 Installs [Bow](https://github.com/Evedel/bow), Docker Registry Frontend.

## Maintainer

Siarhei Krukau <siarhei.krukau@ihg.com>
