# encoding: UTF-8

name 'esi-docker-registry-solution'

maintainer 'Siarhei Krukau'
maintainer_email 'siarhei.krukau@ihg.com'

license 'All rights reserved'
description 'ESI Docker Registry'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))

version '1.0.0'

depends 'docker', '~> 2.0'
