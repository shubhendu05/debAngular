package com.ihg.enterprise.crs.availability.config;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.SerializationFeature;

import com.ihg.enterprise.crs.availability.handler.RedemptionResponseErrorHandler;
import com.ihg.enterprise.crs.availability.interceptor.HspsSwitchInterceptor;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.validation.JAXRSBeanValidationFeature;
import org.apache.cxf.validation.BeanValidationProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JSR310Module;
import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;

import com.ihg.enterprise.crs.availability.controller.AvailabilityController;
import com.ihg.enterprise.crs.availability.controller.OfferServiceController;
import com.ihg.enterprise.crs.availability.handler.GrsResponseErrorHandler;
import com.ihg.enterprise.crs.availability.handler.InternalServerErrorExceptionHandler;
import com.ihg.enterprise.crs.availability.handler.InvalidRequestExceptionHandler;
import com.ihg.enterprise.crs.availability.handler.ServiceCallExceptionHandler;
import com.ihg.enterprise.crs.availability.handler.ValidationExceptionHandler;
import com.ihg.enterprise.crs.availability.interceptor.GrsLoggingInterceptor;
import com.ihg.enterprise.crs.availability.interceptor.HspsSwitchInterceptor;
import com.ihg.enterprise.crs.availability.interceptor.LoggingInterceptor;
import com.ihg.enterprise.crs.availability.provider.HibernateValidationProviderResolver;
import com.ihg.enterprise.crs.availability.provider.JaxrsParamConverterProvider;
import com.ihg.enterprise.crs.availability.provider.LocalDateParamConverter;
import com.ihg.enterprise.inspection.jaxrs.IFSwitcherFilter;
import com.ihg.enterprise.inspection.jaxrs.outbound.resttemplate.RestTemplateLoggingProvider;
import com.ihg.enterprise.schema.crs.reservations.availability.servicetypes.ObjectFactory;

@Configuration
public class Config
{
  @Value("${grs.request.timeout}")
  int grsRequestTimeout;

  @Value("${grs.read.timeout}")
  int grsReadTimeout;

  @Value("http://0.0.0.0:8281/availability/v2")
  String availServiceUrl;

  @Value("http://0.0.0.0:8281/inventory/v2")
  String inventoryServiceUrl;

  @Value("${ras.service.url}")
  String rasServiceUrl;

  @Autowired(required = false)
  RestTemplateLoggingProvider restTemplateLoggingProvider;

  @Bean
  ObjectMapper getObjectMapper()
  {
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.registerModule( new JSR310Module() );
    objectMapper.setSerializationInclusion( JsonInclude.Include.NON_NULL );
    objectMapper.configure( DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false );
    objectMapper.configure( SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false );
    return objectMapper;
  }

  /**
   * Rest Template to send requests to GRS. Configured as buffered to work with {@link BufferingClientHttpRequestFactory } to enable retrieve body within interceptor.
   * Supports only {@link MappingJackson2HttpMessageConverter}.
   * <p>
   * Errors from grs service handles by {@link GrsResponseErrorHandler}
   */
  @Bean
  @Qualifier("grsRestTemplate")
  RestTemplate grsRestTemplate()
  {
    HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();
    httpRequestFactory.setConnectTimeout( grsRequestTimeout );
    httpRequestFactory.setReadTimeout( grsReadTimeout );

    BufferingClientHttpRequestFactory bufferingClientHttpRequestFactory = new BufferingClientHttpRequestFactory(
      httpRequestFactory );
    RestTemplate restTemplate = new RestTemplate( bufferingClientHttpRequestFactory );
    restTemplate.setErrorHandler(grsResponseErrorHandler() );
    MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter = new MappingJackson2HttpMessageConverter();
    mappingJackson2HttpMessageConverter.setObjectMapper( getObjectMapper() );
    restTemplate.setMessageConverters( Collections.singletonList( mappingJackson2HttpMessageConverter ) );

    restTemplate.setInterceptors(
            restTemplateLoggingProvider == null ?
            Collections.singletonList( new GrsLoggingInterceptor() ) :
            Arrays.asList(
                    new GrsLoggingInterceptor(),
                    restTemplateLoggingProvider
            ));

    return restTemplate;
  }

  @Bean
  @Qualifier("restTemplate")
  RestTemplate restTemplate()
  {
    HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();
    httpRequestFactory.setConnectTimeout( grsRequestTimeout );
    httpRequestFactory.setReadTimeout( grsReadTimeout );

    BufferingClientHttpRequestFactory bufferingClientHttpRequestFactory = new BufferingClientHttpRequestFactory(
      httpRequestFactory );
    RestTemplate restTemplate = new RestTemplate( bufferingClientHttpRequestFactory );
    restTemplate.setErrorHandler( redemptionResponseErrorHandler() );
    MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter = new MappingJackson2HttpMessageConverter();
    mappingJackson2HttpMessageConverter.setObjectMapper( getObjectMapper() );
    restTemplate.setMessageConverters( Collections.singletonList( mappingJackson2HttpMessageConverter ) );

    restTemplate.setInterceptors(
            restTemplateLoggingProvider == null ?
            Collections.singletonList( new LoggingInterceptor() ) :
            Arrays.asList(
                    new LoggingInterceptor(),
                    restTemplateLoggingProvider
            ));

    return restTemplate;
  }

  @Bean
  @Qualifier("redemptionResponseErrorHandler")
  ResponseErrorHandler redemptionResponseErrorHandler()
  {
    return new RedemptionResponseErrorHandler();
  }

  @Bean
  @Qualifier("grsResponseErrorHandler")
  ResponseErrorHandler grsResponseErrorHandler()
  {
    return new GrsResponseErrorHandler();
  }

  /**
   * Web Service Template to send requests to RAS (XML).
   */
  @Bean
  @Qualifier("rasWebServiceTemplate")
  WebServiceTemplate rasWebServiceTemplate()
  {
    WebServiceTemplate template = new WebServiceTemplate( getJaxb2Marshaller() );
    template.setDefaultUri( rasServiceUrl );
    return template;
  }

  @Bean
  Jaxb2Marshaller getJaxb2Marshaller()
  {
    ObjectFactory objectFactory = new ObjectFactory();
    Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
    jaxb2Marshaller.setContextPath( objectFactory.getClass().getPackage().getName() );
    jaxb2Marshaller.setBeanClassLoader( objectFactory.getClass().getClassLoader() );
    return jaxb2Marshaller;
  }

  @Bean
  IFSwitcherFilter getIFSwitcherFilter()
  {
    return new IFSwitcherFilter();
  }

  @Bean
  LocalDateParamConverter getLocalDateConverter()
  {
    return new LocalDateParamConverter();
  }

  @Bean
  JAXRSBeanValidationFeature getValidationFeature()
  {
    JAXRSBeanValidationFeature beanValidationFeature = new JAXRSBeanValidationFeature();
    beanValidationFeature.setProvider( getBeanValidationProvider() );
    return beanValidationFeature;
  }

  @Bean
  HibernateValidationProviderResolver getHibernateValidationProviderResolver()
  {
    return new HibernateValidationProviderResolver();
  }

  @Bean
  BeanValidationProvider getBeanValidationProvider()
  {
    return new BeanValidationProvider( getHibernateValidationProviderResolver() );
  }

  @Bean
  JacksonJsonProvider getJacksonJsonProvider()
  {
    JacksonJsonProvider jacksonJsonProvider = new JacksonJsonProvider();
    jacksonJsonProvider.setMapper( getObjectMapper() );
    return jacksonJsonProvider;
  }

  @Bean
  HspsSwitchInterceptor getHspsSwitchInterceptor()
  {
    return new HspsSwitchInterceptor();
  }

  @Bean(name = "hspsSwitchOperationsMap")
  Map getHspsSwitchOperationsMap()
  {
    return new HashMap<String, String>() {
      {
        put( "postSinglePropertyRequest", "single_avail_v2_switch" );
        put( "postMultiPropertyRequest", "multi_avail_v2_switch" );
        put( "postPricingRequest", "retrieve_pricing_v2_switch" );
      }
    };
  }

  @Bean(name = "availabilityServer")
  JAXRSServerFactoryBean getAvailServer( AvailabilityController availabilityController,
    OfferServiceController offerServiceController, LocalDateParamConverter localDateParamConverter )
  {
    JAXRSServerFactoryBean sf = new JAXRSServerFactoryBean();
    sf.setServiceBeans( Arrays.asList( availabilityController, offerServiceController ) );
    sf.setAddress( availServiceUrl );
    sf.getInInterceptors().add( getHspsSwitchInterceptor() );
    sf.setProviders( Arrays.asList(
      getJacksonJsonProvider(),
      getIFSwitcherFilter(),
      new ValidationExceptionHandler(),
      new InvalidRequestExceptionHandler(),
      new ServiceCallExceptionHandler(),
      new InternalServerErrorExceptionHandler(),
      new JaxrsParamConverterProvider( localDateParamConverter ) ) );

    sf.setFeatures( Collections.singletonList( getValidationFeature() ) );

    LoggingInInterceptor loggingInInterceptor = new LoggingInInterceptor();
    LoggingOutInterceptor loggingOutInterceptor = new LoggingOutInterceptor();

    sf.getOutInterceptors().add( loggingOutInterceptor );
    sf.getOutFaultInterceptors().add( loggingOutInterceptor );
    sf.getInInterceptors().add( loggingInInterceptor );
    sf.getInFaultInterceptors().add( loggingInInterceptor );

    sf.create();
    return sf;
  }

}
